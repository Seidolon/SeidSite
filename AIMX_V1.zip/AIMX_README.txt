-=-=-=- INSTALLATION INSTRUCTIONS -=-=-=-

Open zandronum config file and navigate to [Doom.Bindings]
Paste these three lines at the bottom of the list:

.=aimxoptionsmenu
/=aimxactivate
,=aimxplayercontrol

You can change the . / and , to any keys you would rather use
Save the config and run zandronum with AIMX_V1.pk3

Optionally you could just type the same commands...

aimxoptionsmenu
aimxactivate
aimxplayercontrol

...into the console to get the same effect.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

Once you start up Zandronum, you need to enter the Konami Code to gain Admin Access. The code is:

forward,forward,backward,backward,strafeleft,straferight,strafeleft,straferight,use,fire

You can edit the konami code in the pk3 file by opening the SRC folder, then opening AIMX.acs, and editing the constant KONAMICODE_LENGTH and the int array konamicode.
Once you enter the konami code, you need to press the "aimxactivate" key (/) or type it into the console, and you will turn on wallspy and aimx as well as have access to
the "aimxoptionsmenu" (.) and aimxplayercontrol (,). 

With aimxoptionsmenu, you can change your own settings for aimx and enable certain modes like invisibility, invulnerability, cactus mode, super speed, flight, and my favorite: aimx exclusive weapons. 

With aimxplayercontrol, you can give other players aimx access, admin access, warp players to you or vice versa.

AimX exclusive weapons are at weapon slot 0. Every AimX exclusive weapon has an alt fire except the wall-rifle.